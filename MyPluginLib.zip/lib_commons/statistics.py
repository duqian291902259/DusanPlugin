# 此脚本的作用：脚本生成 Swift&Kotlin 打点类，简化调用参数使用
# 使用：
# 1.FBI的'元数据管理'导入对应项目打点json。
# 2.进入脚本所在路径，然后命令行执行命令：python3 statistics.py app-hiiclub-v2.json（导出的json的路径）
# 3.生成的打点工具类，引入工程即可使用。
# 环境依赖： python3（brew install python3）、jinja2（pip3 install jinja2

import os
import json
import time
import jinja2
import shutil
import sys

def generate_template_code(config_path: str, save_path: str):
    """
    根据json配置文件，自动生成打点代码文件
    :param config_path: json配置文件路径地址
    :param save_path: 生成的代码文件保存目录
    :return:
    """
    data = []
    if not os.path.exists(config_path):
        raise Exception("文件不存在，请检查文件路径")
    try:
        content = json.load(open(config_path, "r", encoding="utf-8"))
    except:
        raise Exception("文件不是一个json格式，请检查格式是否正确")
    if os.path.exists(save_path):
        shutil.rmtree(save_path)
    os.mkdir(save_path)
    for element in content:
        element = dict(element)
        temp_json = {}
        action = element.get("action", "")
        if action:
            temp_json["action"] = action
            name_list = action.split("_")
            name_list_cap = list(map(lambda x: str(x).capitalize(), name_list))
            temp_json["func_name"] = "report" + "".join(name_list_cap).replace("-", "")  # 函数名字
        else:
            raise Exception("action为空")

        temp_json["annotation_header"] = element.get("timing", "")
        #temp_json["annotation_foot"] = "highPriority 是否高优先级"
        if len(element["params"]) == 0:
            temp_json["params"] = []
        else:
            element_list = list(element["params"])
            for i in range(len(element_list)):
                name = element_list[i]["name"]
                element_list[i]["origin"] = name
                name_split = str(name).split("_")
                if len(name_split) > 1:
                    ret_list = list(map(lambda x: str(x).capitalize(), name_split[1:]))
                    ret_str = name_split[0] + "".join(ret_list)
                    element_list[i]["name"] = ret_str
            temp_json["params"] = element_list
            param_str = ""
            param_str_swift = ""
            for param in temp_json["params"]:
                param_str += f"{param['origin']}:${param['name']},"
                param_str_swift += f"{param['origin']}:\({param['name']}),"
            #temp_json["kt_log"] = f"Log.d(\"DatingReporter\", \"action:{action},{param_str[:-1]}\")"
        data.append(temp_json)

    current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    current_date = time.strftime("%Y/%m/%d", time.localtime())
    current_year = time.strftime("%Y", time.localtime())
    kt_content = """
package com.dating.lovey.lib_commons.statistics.auto

import com.dating.lovey.lib_commons.statistics.StaticsReporter

/**
 * Description:Musee项目埋点上报，自动生成。
 * 研发，BI，测试，产品看数据，都以埋点文档为准。
 * 真人线需求打点：https://nemo.yuque.com/caq9mt/ynwtsg/yi7ulp/
 * 融合线需求打点：https://nemo.yuque.com/caq9mt/ynwtsg/xcu92k#G4Fl
 * 将excel表格导入BI，自动生成埋点的定义。再从BI到处json格式的埋点定义，交给python脚本自动生成改埋点工具类。
 * 请注意，自动生成后替换该文件，要检查下修改点，避免影响已有的上报逻辑。
 *
 * Created by Musee on 2023/2/14 - 11:00.
 * E-mail: duqian@flatincbr.com
 */
object DatingReporter {
{% for content in data %}
    /**
     * {{content.annotation_header}}
     {% if content.params %}{% for param in content.params %}
* @param {{ param.name }} {{ param.comment }}
     {% endfor %}{% endif %}
*/
    fun {{content.func_name}}({% if content.params %}{% for param in content.params %}{{param.name}}: String = "",{% endfor %}{% endif %}) {
        StaticsReporter("{{ content.action }}")
{% if content.params %}
        {% for param in content.params %}
    .put("{{ param.origin }}", {{ param.name }})
        {% endfor %}{% endif %}
    .report()
    }
{% endfor %}
}
"""
    kt_template = jinja2.Template(kt_content, trim_blocks=True)
    _text = kt_template.render(data=data, current_time=current_time)

    if os.path.isdir(save_path):
        save_path_full = os.path.join(save_path, "DatingReporter.kt")
        with open(save_path_full, "w") as pf:
            pf.write(_text)
        current_path = os.getcwd()
        os.chdir(save_path)
        os.system("ktlint -F \"*.kt\"")
        os.chdir(current_path)
if __name__ == '__main__':
    path = sys.argv[1]
    # todo:外部传入路径
    sourceDir = "src/main/java/com/dating/lovey/lib_commons/statistics/auto"
    targetDir = os.path.join(os.getcwd(),sourceDir)
    if not os.path.exists(targetDir):
        os.makedirs(targetDir)
    generate_template_code(path,targetDir)
