
package com.dating.lovey.lib_commons.statistics.auto

import com.dating.lovey.lib_commons.statistics.StaticsReporter

/**
 * Description:Musee项目埋点上报，自动生成。
 * 研发，BI，测试，产品看数据，都以埋点文档为准。
 * 真人线需求打点：https://nemo.yuque.com/caq9mt/ynwtsg/yi7ulp/
 * 融合线需求打点：https://nemo.yuque.com/caq9mt/ynwtsg/xcu92k#G4Fl
 * 将excel表格导入BI，自动生成埋点的定义。再从BI到处json格式的埋点定义，交给python脚本自动生成改埋点工具类。
 * 请注意，自动生成后替换该文件，要检查下修改点，避免影响已有的上报逻辑。
 *
 * Created by Musee on 2023/2/14 - 11:00.
 * E-mail: duqian@flatincbr.com
 */
object DatingReporter {
    /**
     * Http请求成功率
网络请求的各个阶段的耗时统计
     * @param method post/get
     * @param url 请求url，包含了scheme,host,port,path。上报这个，下面4个可不用
     * @param duration 请求总耗时
     * @param result 请求结果，0成功，1失败，2取消
     * @param code 当前请求最后一次转发流程的HTTP状态码（如果有）
     * @param reason 失败原因
     */
    fun reportFtNetRequest(method: String = "",url: String = "",duration: String = "",result: String = "",code: String = "",reason: String = "",) {
        StaticsReporter("ft_net_request")
            .put("method", method)
            .put("url", url)
            .put("duration", duration)
            .put("result", result)
            .put("code", code)
            .put("reason", reason)
            .report()
    }
    /**
     * 支付假页面曝光
点击continue创单时所选的支付方式
当支付方式选择币商，上报子参币商支付方式和币商id
     * @param type show/quit/continue，行为
     * @param payType GP/UPI/merchant，google play支付/sdk支付/币商
     * @param merchantOffer upi/bank，币商支付方式：upi/银行
     * @param content  充值金额
     * @param productId 商品id
     * @param merchantId 币商id
     */
    fun reportPayFakePage(type: String = "",payType: String = "",merchantOffer: String = "",content: String = "",productId: String = "",merchantId: String = "",) {
        StaticsReporter("pay_fake_page")
            .put("type", type)
            .put("pay_type", payType)
            .put("merchant_offer", merchantOffer)
            .put("content", content)
            .put("product_id", productId)
            .put("merchant_id", merchantId)
            .report()
    }
    /**
     * 测试自动生成埋点上报逻辑
     * @param from pro,livmet
     * @param key value
     * @param test11 测试下，后面删除
     */
    fun reportTestBiEvent(from: String = "",key: String = "",test11: String = "",) {
        StaticsReporter("test_bi_event")
            .put("from", from)
            .put("key", key)
            .put("test11", test11)
            .report()
    }
    /**
     * 点击速配按钮→匹配页面
     * @param eventAction show/match_bt，行为：曝光/点击速配按钮
     * @param tag Young/Mature/Busty/Exciting/default，标签：Young/Mature/Busty/Exciting/无
     */
    fun reportMatchPage(eventAction: String = "",tag: String = "",) {
        StaticsReporter("match_page")
            .put("event_action", eventAction)
            .put("tag", tag)
            .report()
    }
    /**
     * 匹配成功。匹配页面→连接页面；连接页面→其他页面
     * @param connectingTime 连接等待时长
     * @param tag Young/Mature/Busty/Exciting/default，标签：Young/Mature/Busty/Exciting/无
     * @param eventAction close
     * @param targetUid 对方uid
     * @param callTagId 通话打点链路标识
     * @param chatId 视频通话打点中的通道号
     */
    fun reportMatchConnectPage(connectingTime: String = "",tag: String = "",eventAction: String = "",targetUid: String = "",callTagId: String = "",chatId: String = "",) {
        StaticsReporter("match_connect_page")
            .put("connecting_time", connectingTime)
            .put("tag", tag)
            .put("event_action", eventAction)
            .put("target_uid", targetUid)
            .put("call_tag_id", callTagId)
            .put("chat_id", chatId)
            .report()
    }
    /**
     * 速配房间页面→其他页面
     * @param targetUid 对方uid
     * @param callTime 通话时长
     * @param tag Young/Mature/Busty/Exciting/default，标签：Young/Mature/Busty/Exciting/无
     * @param callTagId 通话打点链路标识
     * @param chatId 视频通话打点中的通道号
     */
    fun reportMatchCallEnd(targetUid: String = "",callTime: String = "",tag: String = "",callTagId: String = "",chatId: String = "",) {
        StaticsReporter("match_call_end")
            .put("target_uid", targetUid)
            .put("call_time", callTime)
            .put("tag", tag)
            .put("call_tag_id", callTagId)
            .put("chat_id", chatId)
            .report()
    }
    /**
     * 
     * @param eventAction show/match_bt，行为：曝光/点击速配按钮
     * @param role unpay_user/pay_user，角色：未付费用户/付费用户
     */
    fun reportFakeMatchPage(eventAction: String = "",role: String = "",) {
        StaticsReporter("fake_match_page")
            .put("event_action", eventAction)
            .put("role", role)
            .report()
    }
    /**
     * 
     * @param eventAction show/like/skip，行为：曝光/点击爱心按钮/跳过
     * @param role unpay_user/pay_user，角色：未付费用户/付费用户
     */
    fun reportFakeMatchListPage(eventAction: String = "",role: String = "",) {
        StaticsReporter("fake_match_list_page")
            .put("event_action", eventAction)
            .put("role", role)
            .report()
    }
    /**
     * 
     * @param eventAction show/accept/reject，行为：曝光/接听/拒绝
     * @param role unpay_user/pay_user，角色：未付费用户/付费用户
     */
    fun reportFakeMatchCallPage(eventAction: String = "",role: String = "",) {
        StaticsReporter("fake_match_call_page")
            .put("event_action", eventAction)
            .put("role", role)
            .report()
    }
    /**
     * 
     * @param eventAction show，行为：曝光
     * @param connectingTime 连接等待时长
     */
    fun reportFakeMatchConnectPage(eventAction: String = "",connectingTime: String = "",) {
        StaticsReporter("fake_match_connect_page")
            .put("event_action", eventAction)
            .put("connecting_time", connectingTime)
            .report()
    }
}